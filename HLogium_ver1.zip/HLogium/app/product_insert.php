<?php
require '_base.php';
// ----------------------------------------------------------------------------

if (is_post()) {
    // Input
    $product_id      = req('product_id');
    $category        = req('category');
    $product_name    = req('product_name');
    $price           = req('price');
    $product_desc    = req('product_desc');
    $quantity        = req('quantity');

    // Validate Product id
    if ($product_id == '') {
        $_err['product_id'] = 'Please fill in';
    }
    else if (!preg_match('/^P\d{4}$/', $product_id)) {
        $_err['product_id'] = 'Invalid format';
    }
    else if (!is_unique($product_id, 'product', 'product_id')) {
       $_err['product_id'] = 'Duplicated';
    }
    
    // Validate Product Category
    if ($category == '') {
        $_err['category'] = 'Required';
    }
    else if (!array_key_exists($category, $_category)) {
        $_err['category'] = 'Invalid value';
    }

    //Validate Product Name
    if ($product_name == '') {
        $_err['product_name'] = 'Required';
    }
    else if (strlen($product_name) > 100) {
        $_err['product_name'] = 'No more than 100 characters';
    }

    // Validate Price
    if ($price == '') {
        $_err['price'] = 'Required';
    }
    else if (!preg_match('/^\d{1,7}(\.\d{1,2})?$/', $price)) {
        $_err['price'] = 'Enter in Correct Format';
    }

    // Validate Product Description
    if ($product_desc == '') {
        $_err['product_desc'] = 'Required';
    }
    else if (strlen($product_desc) > 255) {
        $_err['product_desc'] = 'No more than 255 characters';
    }

    // Validate Quantity
    if ($quantity == '') {
        $_err['quantity'] = 'Required';
    } 
    else if (!preg_match('/^\d+$/', $quantity)) {
        $_err['quantity'] = 'Enter in Correct Format';
    }

    // Output
    if (!$_err) {
        $stm = $_db->prepare('INSERT INTO product
                            (product_id, category, product_name, price, product_desc, quantity) 
                            VALUES(?, ?, ?, ?, ?, ?)');
        $stm->execute([$product_id, $category, $product_name, $price, $product_desc, $quantity]);
        temp('info', 'Record Inserted Successfully!');
        redirect('product_insert.php');
    }
}

// ----------------------------------------------------------------------------
$_title = 'Insert';
include '_head.php';
?>

<form method="post" class="form">

    <label for="product_id">Product Id</label>
    <?= html_text('product_id', 'maxlength="5" data-upper') ?>
    <?= err('product_id') ?>

    <label for="category">Category</label>
    <?= html_select('category', $_category) ?>
    <?= err('category') ?>

    <label for="product_name">Product Name</label>
    <?= html_text('product_name', 'maxlength="100"') ?>
    <?= err('product_name') ?>

    <label for="price">Price</label>
    <?= html_text('price', 'maxlength="9"') ?>
    <?= err('price') ?>

    <label for="product_desc">Description</label>
    <?= html_text('product_desc', 'maxlength="255"') ?>
    <?= err('product_desc') ?>

    <label for="quantity">Quantity</label>
    <?= html_text('quantity', 'maxlength="4"') ?>
    <?= err('quantity') ?>

    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>

<?php
include '_foot.php';