<?php
require '_base.php';

//-----------------------------------------------------------------------------

$arr = $_db->query('SELECT * FROM product')->fetchAll();

// ----------------------------------------------------------------------------

$_title = 'Product Listing';
include '_head.php';
?>

<p><?= count($arr) ?> record(s)</p> 
<table class="table">
    <tr>
        <th>Product Id</th>
        <th>Category</th>
        <th>Name</th>
        <th>Price</th>
        <th>Description</th>
        <th>Quantity</th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->product_id ?></td>
        <td><?= $s->category ?></td>
        <td><?= $s->product_name ?></td>
        <td><?= $s->price ?></td>
        <td><?= $s->product_desc ?></td>
        <td><?= $s->quantity ?></td>
        <td>
            <!-- TODO -->
            <button  data-get="detail.php?id=<?= $s->id?>">Detail</button>
            <button  data-get="update.php?id=<?= $s->id?>">Update</button>
            <button data-post="delete.php?id=<?= $s->id?>"
            data-confirm>Delete</button>
        </td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';